# ToolbarControl

An interface to control both the Blizzy Toolbar and the stock Toolbar without having to code for each one.
